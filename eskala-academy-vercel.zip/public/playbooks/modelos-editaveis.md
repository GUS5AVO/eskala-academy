# Atendimento que avança



## Prepare o atendimento antes de responder

Antes de responder ao lead, organize uma ficha com código, localização, metragem, ambientes, vagas, preço confirmado, disponibilidade e responsável pela informação. Registre a data da consulta. Condições de entrada e financiamento só entram quando estiverem verificadas para aquela operação.
O imóvel atrai a conversa, mas a rotina do comprador orienta a escolha. Prepare duas perguntas sobre localização e necessidade. Não envie dez opções antes de entender a procura.

### Modelo

[Nome], esse imóvel fica em [bairro] e tem [característica confirmada]. O que mais pesa na sua escolha hoje: localização, espaço ou prazo para mudar?

### Exercício

Preencha uma ficha de um imóvel e escreva duas perguntas sobre a rotina do comprador.



## Abra a conversa com uma pergunta útil

Mostre que você entendeu de onde veio o contato. Cite o imóvel ou conteúdo que despertou interesse e faça uma pergunta de cada vez. Depois de ouvir, explique o próximo passo. Uma resposta curta e pertinente facilita a continuidade.
Se a pessoa só pede preço, informe o preço confirmado. Não esconda a informação para forçar uma conversa. Em seguida, pergunte o que precisa saber para orientar melhor.

### Modelo

Oi, [nome]! O valor anunciado é [preço confirmado]. Para eu entender se esse imóvel combina com você: está buscando para morar ou investir?

### Exercício

Escreva três aberturas: anúncio de imóvel, indicação e contato pelo perfil.



## Qualifique sem prometer aprovação

Descubra finalidade da compra, região, tipo de imóvel e prazo desejado. Se houver interesse em financiamento, explique por que algumas informações serão necessárias na análise. Peça permissão para encaminhar ao responsável e siga o canal definido pela operação para documentação.
A conversa comercial não substitui análise de crédito. Não conclua enquadramento, benefício ou aprovação a partir de uma mensagem. Quando não souber uma condição, registre a dúvida e combine quem verificará e quando retornará.

### Modelo

Você já fez alguma análise de financiamento? Se ainda não, posso te explicar como funciona o encaminhamento para verificar as possibilidades do seu perfil.

### Exercício

Crie uma ficha com necessidade, região, prazo, análise existente e próximo passo combinado.



## Responda à dúvida antes de tentar convencer

Uma objeção pode esconder falta de informação, insegurança ou incompatibilidade real. Pergunte qual é o ponto exato. Se a entrada não cabe, não repita que o imóvel é uma oportunidade: verifique se existe condição confirmada ou se é melhor buscar outra opção.
Evite urgência inventada. Uma decisão de compra exige compreensão. O objetivo é esclarecer e permitir uma escolha consciente, mantendo o contato aberto quando a compra ainda não faz sentido.

### Modelo

Quando você diz que prefere pensar, qual ponto ficou mais em aberto: o imóvel, os valores ou o momento de comprar? Posso esclarecer esse ponto primeiro.

### Exercício

Prepare respostas para entrada, localização e prazo, sempre incluindo uma pergunta e um próximo passo.



## Marque uma visita com propósito

A visita deve responder a uma dúvida concreta do comprador: espaço, localização, acabamento ou adequação à rotina. Recapitule o que ele busca e explique por que o imóvel merece ser conhecido. Ofereça horários que estejam realmente disponíveis.
Confirme endereço, ponto de encontro, duração aproximada e quem participará. Depois da visita, pergunte o que funcionou e o que não funcionou. Registre uma ação, um responsável e uma data, inclusive quando a decisão for continuar procurando.

### Modelo

Pelo que você me contou sobre [necessidade], vale avaliar [característica] pessoalmente. Tenho [horário A] ou [horário B] disponíveis. Algum funciona para você?

### Exercício

Monte sua confirmação de visita e um roteiro de três perguntas para depois dela.



# Conteúdo que abre conversas



## Defina uma mensagem por conteúdo

Um conteúdo curto funciona melhor quando tem uma tarefa clara. Escolha uma dúvida específica: como preparar uma visita, o que levantar antes de uma análise ou como comparar dois bairros na própria rotina. Misturar todos os assuntos produz um vídeo difícil de acompanhar.
Em Santa Catarina, personalize cidade, bairro e referências locais verificadas. Evite chamar uma região de valorização garantida. Use fatos observáveis e explique para quem uma característica pode ser útil.

### Modelo

Antes de escolher um imóvel em [cidade], pense no trajeto que você faz todos os dias. Trabalho, escola e transporte podem mudar o que é uma boa localização para você.

### Exercício

Liste cinco pautas com dúvida, resposta central e pergunta final.



## Grave um vídeo que entrega uma resposta

Comece pela situação do comprador e entregue a resposta sem uma introdução longa sobre sua trajetória. Depois, mostre o exemplo: ambiente, localização ou ficha. Termine com uma pergunta pertinente ao assunto.
A duração deve acompanhar a explicação. Grave com áudio compreensível, iluminação suficiente e enquadramento estável. Coloque legendas e revise nomes, números e condições. Não mostre documentos nem dados de clientes no fundo da gravação.

### Modelo

Vai visitar seu primeiro imóvel? Além de olhar os ambientes, confira ventilação, ruídos e como o espaço atende à sua rotina. Qual desses pontos pesa mais para você?

### Exercício

Grave um vídeo respondendo uma dúvida em até três blocos de fala.



## Apresente o imóvel com dados e utilidade

Uma boa divulgação combina informações verificadas com utilidade. Duas vagas, por exemplo, podem ser relevantes para uma família com dois veículos; não são uma vantagem universal. Descreva o que existe e deixe o comprador avaliar a compatibilidade.
Use preço e disponibilidade atualizados. Se uma condição depender de análise, isso precisa ficar claro junto da condição. Não anuncie enquadramento no MCMV apenas porque o imóvel parece popular: confirme o que se aplica antes de divulgar.

### Modelo

[Tipo de imóvel] em [bairro], [cidade]. São [área] m², [quartos] e [vagas]. [Característica confirmada] pode fazer sentido para quem busca [necessidade]. Valor: [preço]. Referência: [código]. Saiba mais.

### Exercício

Escreva uma apresentação de um imóvel usando apenas informações confirmadas.



## Monte uma semana possível de executar

Organize três conteúdos por semana como exercício inicial: uma dúvida, um imóvel e um bastidor útil. O bastidor pode mostrar como você prepara a ficha ou planeja uma visita, sem expor clientes. Reaproveite o assunto nos stories com outra abordagem.
Planeje também tempo para responder. Publicar e deixar conversas paradas quebra a continuidade. A cadência deve caber na rotina do corretor; aumente apenas quando conseguir manter qualidade e atendimento.

### Modelo

Story 1: O que você considera essencial no primeiro imóvel? Story 2: Mostre um exemplo real dessa característica. Story 3: Pergunte em qual região a pessoa está procurando.

### Exercício

Preencha sete dias com pauta, formato, material necessário e horário de resposta.



## Avalie conversas, não apenas visualizações

Registre assunto, formato, data e conversas iniciadas. Depois, acompanhe quantas conversas tinham necessidade compatível com sua carteira e quais chegaram a uma visita. Curtidas e visualizações ajudam a entender alcance, mas não mostram sozinhas o resultado comercial.
Não atribua toda venda ao último post: o comprador pode ter visto vários conteúdos e recebido indicação. Compare períodos semelhantes e use poucas observações como sinais, não como prova definitiva.

### Modelo

Para eu entender como você chegou até aqui: foi pelo vídeo de [tema], por um anúncio ou por indicação?

### Exercício

Crie um registro para os próximos três posts e anote as conversas relacionadas.



# Oportunidades em movimento



## Transforme contatos em uma lista de ações

Use uma planilha ou o CRM da operação. Registre apenas o necessário: identificador, origem, necessidade, região, etapa, último contato, próxima ação, responsável e data. A informação precisa permitir continuar o atendimento sem depender da memória.
Comece com etapas simples: novo contato, em conversa, análise encaminhada, visita, proposta e encerrado. Não marque uma etapa pelo que você gostaria que acontecesse. Atualize quando houver um fato observável.

### Modelo

Registro: contato C-014 | procura apartamento em [região] | visita realizada | próxima ação: confirmar dúvida sobre vaga | responsável: corretor | data: [combinada].

### Exercício

Organize dez oportunidades usando identificadores em vez de expor nomes em materiais compartilhados.



## Faça follow-up com um motivo

Antes de enviar uma mensagem, releia o último combinado. O motivo pode ser uma informação verificada, uma dúvida respondida ou uma disponibilidade compatível. Perguntar repetidamente se a pessoa decidiu acrescenta pouco.
Combine a data de retorno sempre que possível. Se não houver resposta, use uma retomada breve e depois pergunte se a pessoa prefere pausar. Respeite pedidos para encerrar o contato. A sequência deve se adaptar ao contexto, sem disparos insistentes.

### Modelo

Oi, [nome]. Fiquei de confirmar [pendência]. A informação verificada é [resposta]. Isso resolve sua dúvida ou existe outro ponto que precisamos avaliar?

### Exercício

Escreva três retomadas, cada uma ligada a uma pendência real diferente.



## Reative sem fingir uma oportunidade

Contatos antigos podem ter mudado de cidade, comprado ou decidido esperar. Abra a conversa reconhecendo o intervalo e pergunte se a busca continua. Só apresente imóveis depois de atualizar a necessidade. Não use escassez ou condição inventadas para obter resposta.
Faça uma revisão pequena da base, com mensagens contextualizadas. Não exporte cadastros para ferramentas desconhecidas. Use os canais aprovados pela operação e retire da sequência quem pedir para não receber contato.

### Modelo

Oi, [nome]. Há um tempo conversamos sobre [tipo de imóvel] em [região]. Você continua procurando ou esse plano mudou? Posso atualizar meu acompanhamento por aqui.

### Exercício

Revise cinco registros antigos e escreva uma abordagem individual para cada contexto.



## Conduza o pós-visita e a proposta

Após a visita, pergunte o que atendeu e o que não atendeu. Se houver interesse em proposta, organize condições e encaminhe pelo processo da operação. Não apresente uma condição pretendida como aceita pelo proprietário ou construtora.
Registre pendências e responsáveis. Uma proposta sem resposta exige acompanhamento do responsável pela negociação, não uma promessa de resultado ao comprador. Quando o imóvel não servir, use a avaliação para melhorar a próxima seleção.

### Modelo

O que funcionou melhor nesse imóvel? E qual ponto ainda impediria você de avançar? Com isso eu consigo organizar o próximo passo com você.

### Exercício

Crie um resumo pós-visita com pontos positivos, impeditivos, decisão e pendências.



## Revise a operação uma vez por semana

Conte contatos recebidos, conversas qualificadas, visitas realizadas e propostas encaminhadas. Use definições constantes: para este exercício, qualificada significa que necessidade, região e próximo passo foram identificados. Adapte essa definição com a equipe antes de comparar pessoas.
Observe onde os contatos ficam parados e revise exemplos reais. Poucas oportunidades podem distorcer percentuais. Compare também a quantidade de registros e a qualidade das informações. A revisão deve terminar em uma mudança prática para a semana seguinte.

### Modelo

Exemplo ilustrativo: se houve 8 visitas e 2 propostas, a razão observada é 2/8 = 25%. Isso descreve esse conjunto; não é uma meta de mercado nem garantia futura.

### Exercício

Faça sua primeira revisão: um número por etapa, um gargalo e uma ação para os próximos sete dias.

