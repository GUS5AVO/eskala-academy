# Eskala Academy - pacote para Vercel

Origem: versão 791fb56c9500cc6df54a4bc43b3dfc6b5aaba573.

## Importação
Criar um novo projeto chamado eskala-academy na equipe correta. Usar framework Other, sem comando de build ou instalação, saída public. A configuração está em vercel.json.

## Acesso
Este pacote contém os PDFs e as lições completas, além de uma proposta comercial interna. Fazer o primeiro deploy como prévia protegida e verificar a proteção antes de compartilhar. Para produção pública, remover a proposta interna do pacote e colocar os materiais pagos em uma área com autenticação e liberação após pagamento. Links difíceis de adivinhar e progresso no navegador não protegem conteúdo.

## Checkout
A cobrança está desabilitada. Configurar os cinco links HTTPS em public/checkout-config.json e mudar status para active apenas depois de cadastrar os produtos e testar pagamento e entrega. Não colocar segredos nesse arquivo público.

## Domínio
Pesquisa em 15/10/2026: eskalaacademy.com disponível, US$ 11,25 por um ano; renovação US$ 11,25. eskala.academy disponível, US$ 21,99 por um ano; renovação US$ 45,24. Disponibilidade e preços sujeitos a nova consulta antes da compra. A consulta não confirmou disponibilidade de eskalaacademy.com.br. Nenhum domínio foi comprado ou conectado.

## Validação
Testes locais: cinco ofertas, pagamento desabilitado, navegação de lições, avaliação, exercício obrigatório e progresso. Não há autenticação de aluno ou integração de pagamentos. Deploy na Vercel bloqueado pela autorização da equipe (403); publicação não realizada.
